package uninter;
public class Dolar extends Moeda{
	
	//CONSTRUTOR PARA DEFINIR O VALOR DIGITADO INCIAL DA MOEDA `DOLAR` 
	public Dolar(double valorNovo) {
		this.valor = valorNovo;
	}

	//EXIBIÇÃO DO VALOR NA TELA 
	@Override
	public void info() {
		System.out.println("Dolar - " + valor); 	
	}

	//METODO DE CONVERSÃO PARA REAL 
	@Override
	public double converter() {
		return this.valor * 5.16;
	}

	//COMPARAÇÃO DE VALORES 
	@Override
	public int hashCode() {
		return super.hashCode();
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		return true;
	}
}
