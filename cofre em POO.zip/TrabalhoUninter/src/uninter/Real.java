package uninter;
public class Real extends Moeda {
	
	//CONSTRUTOR PARA DEFINIR O VALOR DIGITADO INICIAL DA MOEDA `REAL` 
		public Real(double valorNovo) {
			this.valor = valorNovo;
		}
	
	//EXIBIÇÃO DO VALOR NA TELA
	@Override
	public void info() { 
		System.out.println("Real - " + valor);
	}

	//METODO DE CONVERSÃO PARA REAL (NAO É NECESSARIO CALCULO, SÓ VOU RETORNAR O VALOR)
	@Override
	public double converter() {
		return this.valor;	
	}
	
	//COMPARAÇÃO DE VALORES
	@Override
	public int hashCode() {
		return super.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		return true;
	}
}
