package uninter;
public class Euro extends Moeda{
		
		//CONSTRUTOR PARA DEFINIR O VALOR DIGITADO INICIAL DA MOEDA `EURO` 
		public Euro(double valorNovo) {
			this.valor = valorNovo;
		}

		//EXIBIÇÃO DO VALOR NA TELA
		@Override
		public void info() {
			System.out.println("Euro - " + valor); 	
		}

		//MÉTODO DE CONVERSÃO PARA REAL 
		@Override
		public double converter() {
			return this.valor * 5.56;
		}

		//COMPARAÇÃO DE VALORES 
		@Override
		public int hashCode() {
			return super.hashCode();
		}
		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (!super.equals(obj))
				return false;
			if (getClass() != obj.getClass())
				return false;
			return true;
		}	
	}


