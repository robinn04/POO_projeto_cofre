package uninter;
import java.util.ArrayList;
public class Cofrinho {
	
	private ArrayList<Moeda> moedaLista = new ArrayList<Moeda>();
		
	//ADICIONAR UM VALOR A MOEDA 
		public void adicionar(Moeda a) {
			moedaLista.add(a);
		}
	
	//REMOVER UM VALOR DE UMA MOEDA 
		public void remover(Moeda a) {
			moedaLista.remove(a);
		}
		
	//LISTAR AS MOEDAS 
		public void listagemMoedas() {
			for (Moeda a : moedaLista) {
				a.info();
		}
	}
		
	//CONVERÇÃO DO VALOR TOTAL DAS MOEDAS 
		public double converter() {
			if (moedaLista.isEmpty()) {
			return 0;
		}
	//A VARIAVEL "totalConvertido" SE TRATA DE UMA VARIAVEL ACUMULADORA, VAI AJUDAR NO CALCULO DA CONVERSÃO 
			double totalConvertido = 0;
				for (Moeda a : moedaLista) {
					totalConvertido  = a.converter() + totalConvertido;
				}
			return totalConvertido;
	}
}
