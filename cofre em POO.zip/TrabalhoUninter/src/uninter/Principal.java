package uninter;
import java.util.Scanner;
public class Principal {
	
		public static void main(String[] args) {
			
		//MENU DE ESCOLHA DAS OPÇÕES 
		Scanner teclado = new Scanner(System.in);
		int escolha;
	
		Cofrinho cofrinho = new Cofrinho();
		
		System.out.println("----COFRINHO----");
		System.out.println("1- Adicionar moeda");
		System.out.println("2- Remover moeda");
		System.out.println("3- Listar moedas");
		System.out.println("4- Calcular valor convertido para real");
		System.out.println("0- Encerrar");
		escolha=teclado.nextInt();
		
		//AS VARIÁVEIS A BAIXO FORAM CRIADAS ANTES PARA NAO DAR CONFLITO ENTRE O CASE 1 E O CASE 2 
		double tipoMoeda;
		double valorAdicionado;
		Moeda moedaAdd;
		
		while(escolha != 0){
			switch (escolha) {
			
			//OPÇÃO 1-> ADICIONAR MOEDA
			case 1:
				tipoMoeda=0;
				while(tipoMoeda>3 || tipoMoeda<=0) {
					System.out.println("Escolha a moeda");
					System.out.println("1- Real");
					System.out.println("2- Dolar");
					System.out.println("3- Euro");
					tipoMoeda = teclado.nextInt();					
				}
				
				System.out.println("Digite o valor: ");
				valorAdicionado = teclado.nextDouble();
				
				moedaAdd = null;
				
				if (tipoMoeda == 1) {
					moedaAdd = new Real(valorAdicionado);
				}
				else if (tipoMoeda == 2) {
					moedaAdd = new Dolar(valorAdicionado);
				}
				if (tipoMoeda == 3) {
					moedaAdd = new Euro(valorAdicionado);
				}
				
				cofrinho.adicionar(moedaAdd);
				System.out.println("Moeda adicionada com sucesso!");
				break;
				
			//OPÇÃO 2-> REMOVER MOEDA
			case 2:
				tipoMoeda=0;
				while(tipoMoeda>3 || tipoMoeda<=0) {
					System.out.println("Escolha a moeda");
					System.out.println("1- Real");
					System.out.println("2- Dolar");
					System.out.println("3- Euro");
					tipoMoeda = teclado.nextInt();					
				}
				
				System.out.println("Digite o valor: ");
				valorAdicionado = teclado.nextDouble();
				
				moedaAdd = null;
				
				if (tipoMoeda == 1) {
					moedaAdd = new Real(valorAdicionado);
				}
				else if (tipoMoeda == 2) {
					moedaAdd = new Dolar(valorAdicionado);
				}
				if (tipoMoeda == 3) {
					moedaAdd = new Euro(valorAdicionado);
				}
				
				cofrinho.remover(moedaAdd);
				System.out.println("Moeda removida com sucesso!");
			
				break;
				
			//OPÇÃO 3-> LISTAR MOEDA
			case 3:
				cofrinho.listagemMoedas();
				break;
				
			//OPÇÃO 4->	CALCULAR VALOR CONVERTIDO PARA REAL
			case 4:
				double totalConvertido = cofrinho.converter();
				System.out.println("O valor convertido para real? " + totalConvertido);
				break;
				
			default:
				System.out.println("Opção invalida. Por favor digite "
						+ "valores numericos de 0 a 4");
			}
		
			System.out.println("----COFRINHO----");
			System.out.println("1- Adicionar moeda");
			System.out.println("2- Remover moeda");
			System.out.println("3- Listar moedas");
			System.out.println("4- Calcular valor convertido para real");
			System.out.println("0- Encerrar");
			escolha=teclado.nextInt();
			
		}
	}	
}
